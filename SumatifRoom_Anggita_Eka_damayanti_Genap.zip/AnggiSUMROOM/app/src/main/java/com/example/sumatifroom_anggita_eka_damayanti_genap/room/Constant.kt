package com.example.sumatifroom_anggita_eka_damayanti_genap.room

class Constant {
    companion object{
        const val TYPE_READ= 0
        const val TYPE_CREATE = 1
        const val TYPE_UPDATE = 2
    }
}